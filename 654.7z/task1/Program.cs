﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using task1.Core;

namespace task1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Задание 1

            //Address address = new Address();
            //address.Index = 301760;
            //address.Country = "Russia";
            //address.City = "Donskoy";
            //address.Street = "Terpit";
            //address.House = "17A";
            //address.Apartment = 36;
            //Console.WriteLine($"Index: {address.Index}\n Country: {address.Country} \n City: {address.City}\n Street: {address.Street} \n House: {address.House}\n Apartment: {address.Apartment}");
            //Thread.Sleep(3000)

            // Задание 2

            //Rectangle rectangle = new Rectangle(25, 2);
            //double plo = rectangle.Side1 * rectangle.Side2;
            //Console.WriteLine($"Площадь: {plo}");
            //double per = 2 * (rectangle.Side1 + rectangle.Side2);
            //Console.WriteLine($"Периметр: {per}");
            //Thread.Sleep(3000);

            //Задание 3

            //Console.ForegroundColor = ConsoleColor.Green;
            //Book book = new Book("Книжная");
            //book.Show();
            //Console.ForegroundColor = ConsoleColor.Yellow;
            //Title title = new Title("Почему?");
            //title.Show();
            //Console.ForegroundColor = ConsoleColor.Red;
            //Author author = new Author("Я");
            //author.Show();
            //Console.ForegroundColor = ConsoleColor.Magenta;
            //Content content = new Content("Почему это сложнее, чем с# в прошлом году?! \nЦвет изменился... НЕ МОЖЕТ БЫТЬ!");
            //content.Show(); 
            //Thread.Sleep(3000);

            //Задание 4

            Figure figure = new Figure();
            double per = figure.MyProperty.Num1 + figure.MyProperty.Num2;
            Console.WriteLine($"Периметр: {per}");

            string LengthSide = figure.MyProperty.Name;
            Console.WriteLine($"Многоугольник: {LengthSide}");

            Thread.Sleep(3000);
        }

    }
}