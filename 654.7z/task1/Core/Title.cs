﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1.Core
{
    public class Title
    {
		private string _titlee;

        public Title(string titlee)
        {
            Titlee = titlee;
        }

        public string Titlee
		{
			get { return _titlee; }
			set { _titlee = value; }
		}

        public void Show()
        {
            Console.WriteLine($"Название: {Titlee}");
        }

    }
}
