﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1.Core
{
    public class Content
    {
		private string _contentt;

        public Content(string contentt)
        {
            Contentt = contentt;
        }

        public string Contentt
		{
			get { return _contentt; }
			set { _contentt = value; }
		}

        public void Show()
        {
            Console.WriteLine($"Содержание: {Contentt}");
        }

    }
}
