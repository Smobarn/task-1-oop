﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1.Core
{
    public class Book
    {
		private string _bookn;

        public Book(string bookn)
        {
            Bookn = bookn;
        }

        public string Bookn
		{
			get { return _bookn; }
			set { _bookn = value; }
		}

        public void Show()
        {
            Console.WriteLine($"Книга: {Bookn}");
        }
    }
}
