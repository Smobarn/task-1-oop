﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1.Core
{
    public class Figure
    {
        public Point MyProperty { get; set; }
        public Figure()
        {
            MyProperty = new Point("Две линии",25,7);
        }
    }
}
